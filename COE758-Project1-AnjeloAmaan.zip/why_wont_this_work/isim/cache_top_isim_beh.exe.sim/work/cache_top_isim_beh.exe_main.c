/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    xilinxcorelib_ver_m_04284627112054182733_1579357631_init();
    xilinxcorelib_ver_m_04284627112054182733_2881984826_init();
    xilinxcorelib_ver_m_18166792875774041790_1525216201_init();
    xilinxcorelib_ver_m_17738287534884592592_3450899109_init();
    xilinxcorelib_ver_m_03112275034362415534_3961674548_init();
    work_m_13623000689978195215_0062336315_init();
    work_m_13125446916848769383_0838997979_init();
    work_m_13086441033036553472_3449558636_init();
    work_m_15894965197132622691_2832290113_init();
    work_m_16541823861846354283_2073120511_init();


    xsi_register_tops("work_m_15894965197132622691_2832290113");
    xsi_register_tops("work_m_16541823861846354283_2073120511");


    return xsi_run_simulation(argc, argv);

}
